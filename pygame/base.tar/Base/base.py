#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Very simple game with Pygame
"""

import sys, pygame
import os
import time
from pygame.locals import *
import random

SCREEN_WIDTH = 1024
SCREEN_HEIGHT = 768

# FUNCTIONS
def load_png(name):
    """Load image and return image object"""
    fullname=os.path.join('.',name)
    try:
        image=pygame.image.load(fullname)
        if image.get_alpha is None:
            image=image.convert()
        else:
            image=image.convert_alpha()
    except pygame.error, message:
        print 'Cannot load image:', fullname
        raise SystemExit, message
    return image,image.get_rect()

# CLASSES
class Ship(pygame.sprite.Sprite):
    """Class for the player's ship"""

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image, self.rect = load_png('Pics/ship.png')
        self.rect.center = [SCREEN_WIDTH/2, SCREEN_HEIGHT/2]
        self.speed = [0,0]

    def up(self):
        pass

    def update(self):
        self.rect = self.rect.move(self.speed)


# MAIN

def main_function():
    """Main function of the game"""
    # Initialization
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    clock = pygame.time.Clock()
    pygame.key.set_repeat(1,1)

    # Objects creation
    background_image, background_rect = load_png('Pics/background.jpg')
    ship = Ship() # creation d'une instance de Ship
    ship_sprite = pygame.sprite.RenderClear() # creation d'un groupe de sprite
    ship_sprite.add(ship) # ajout du sprite au groupe de sprites

    # MAIN LOOP
    while True:
        clock.tick(60) # max speed is 60 frames per second

        # Events handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return # closing the window exits the program

        touches=pygame.key.get_pressed()
        if(touches[K_UP]):  
            ship.up()
        if(touches[K_q]):
            return # exit the program 

        # updates
        ship_sprite.update()

        # drawings
        screen.blit(background_image, background_rect)
        ship_sprite.draw(screen)
        pygame.display.flip()
        

if __name__ == '__main__':
    main_function()
    sys.exit(0)
